"""Business logic services for backend domain operations."""
