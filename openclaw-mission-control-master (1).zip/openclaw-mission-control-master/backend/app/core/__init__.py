"""Core utilities and configuration for the backend service."""
