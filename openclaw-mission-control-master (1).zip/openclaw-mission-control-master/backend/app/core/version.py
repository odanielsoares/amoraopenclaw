"""Application name and version constants."""

APP_NAME = "mission-control"
APP_VERSION = "0.1.0"
