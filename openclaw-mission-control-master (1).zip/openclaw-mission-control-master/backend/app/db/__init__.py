"""Database helpers and abstractions for backend persistence."""
