# Coverage policy

Placeholder: coverage policy is currently documented in the root `Makefile` (`backend-coverage`).
