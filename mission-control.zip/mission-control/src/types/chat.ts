export type MessageRole = "user" | "amora";

export type AttachmentType = "image" | "audio";

export type ChatAttachment = {
  id: string;
  type: AttachmentType;
  url: string;
  filename: string;
  duration?: number; // seconds, for audio
  mimeType?: string;
};

export type MessageStatus = "sending" | "sent" | "error";

export type ChatMessage = {
  id: string;
  role: MessageRole;
  content: string;
  attachments: ChatAttachment[];
  timestamp: string;
  status: MessageStatus;
};
