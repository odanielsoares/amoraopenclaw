import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { token } = await req.json();

    // Token is stored server-side in environment variable (never exposed to client)
    const validToken = process.env.AMORA_ACCESS_TOKEN;

    if (!validToken) {
      // If no token configured, reject in production, allow in dev
      if (process.env.NODE_ENV === "development") {
        return NextResponse.json({ ok: true });
      }
      return NextResponse.json({ error: "Token not configured" }, { status: 500 });
    }

    if (token === validToken) {
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
}
