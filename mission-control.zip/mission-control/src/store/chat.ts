import { create } from "zustand";
import type { ChatMessage, ChatAttachment } from "@/types/chat";
import { generateAmoraResponse } from "@/mocks/amora";

function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

interface ChatState {
  messages: ChatMessage[];
  isOpen: boolean;
  isMinimized: boolean;
  isAmoraTyping: boolean;
  unreadCount: number;

  toggleChat: () => void;
  minimizeChat: () => void;
  expandChat: () => void;
  sendMessage: (content: string, attachments?: ChatAttachment[]) => void;
  addAmoraResponse: (message: ChatMessage) => void;
  clearUnread: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [
    {
      id: "welcome",
      role: "amora",
      content:
        "Ola! Sou a **Amora**, sua COO digital. Estou monitorando todos os agentes em tempo real. Como posso ajudar?",
      attachments: [],
      timestamp: new Date().toISOString(),
      status: "sent",
    },
  ],
  isOpen: false,
  isMinimized: true,
  isAmoraTyping: false,
  unreadCount: 0,

  toggleChat: () =>
    set((s) => {
      const opening = !s.isOpen;
      return {
        isOpen: opening,
        isMinimized: !opening,
        unreadCount: opening ? 0 : s.unreadCount,
      };
    }),

  minimizeChat: () => set({ isMinimized: true, isOpen: false }),

  expandChat: () => set({ isMinimized: false, isOpen: true, unreadCount: 0 }),

  clearUnread: () => set({ unreadCount: 0 }),

  sendMessage: (content, attachments = []) => {
    const userMsg: ChatMessage = {
      id: uid(),
      role: "user",
      content,
      attachments,
      timestamp: new Date().toISOString(),
      status: "sent",
    };

    set((s) => ({ messages: [...s.messages, userMsg] }));

    // Simulate Amora typing + response
    set({ isAmoraTyping: true });

    const delay = 1000 + Math.random() * 2000;
    setTimeout(() => {
      const response = generateAmoraResponse(content, attachments);
      const amoraMsg: ChatMessage = {
        id: uid(),
        role: "amora",
        content: response,
        attachments: [],
        timestamp: new Date().toISOString(),
        status: "sent",
      };

      set((s) => ({
        messages: [...s.messages, amoraMsg],
        isAmoraTyping: false,
        unreadCount: s.isOpen ? 0 : s.unreadCount + 1,
      }));
    }, delay);
  },

  addAmoraResponse: (message) =>
    set((s) => ({
      messages: [...s.messages, message],
      isAmoraTyping: false,
      unreadCount: s.isOpen ? 0 : s.unreadCount + 1,
    })),
}));
