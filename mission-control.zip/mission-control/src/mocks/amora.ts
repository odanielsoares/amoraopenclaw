import type { ChatAttachment } from "@/types/chat";
import { useAgentsStore } from "@/store/agents";

const GREETINGS = [
  "Ola! Como posso ajudar?",
  "Oi! Estou de olho em tudo por aqui.",
  "E ai! Todos os sistemas operacionais.",
];

const STATUS_RESPONSES = [
  "Agora temos **{total} agentes** no sistema. {active} ativos, {errors} com erro, {completed} concluidos.",
  "Status geral: **{active} agentes trabalhando**, {waiting} aguardando input e {errors} com problemas. Tudo sob controle.",
  "Painel atualizado: {total} agentes deployados. {active} em operacao, {completed} tarefas finalizadas.",
];

const TASK_RESPONSES = [
  "Entendido! Vou encaminhar essa tarefa para o proximo agente disponivel. Acompanhe no grid.",
  "Tarefa registrada. Vou alocar o melhor agente pra isso. Te aviso quando comecar.",
  "Recebido. Vou priorizar isso na fila de execucao.",
];

const ERROR_RESPONSES = [
  "Identifiquei o problema. Parece ser um timeout na API externa. Vou retentar automaticamente em 30s.",
  "Erro detectado. Ja estou analisando os logs. Vou te dar um diagnostico em instantes.",
  "Vi o erro. Vou redirecionar a tarefa para outro agente enquanto investigo a causa.",
];

const AUDIO_RESPONSES = [
  "Recebi seu audio! Vou processar e executar o que foi solicitado.",
  "Audio recebido e transcrito. Ja estou trabalhando nisso.",
  "Entendi a mensagem de voz. Vou encaminhar para o time.",
];

const IMAGE_RESPONSES = [
  "Imagem recebida! Vou analisar e te dar um retorno.",
  "Vi a imagem. Ja estou processando o conteudo.",
  "Recebi a captura. Vou usar como referencia para a tarefa.",
];

const GENERIC_RESPONSES = [
  "Certo, vou cuidar disso. Alguma prioridade especifica?",
  "Entendido. Posso te dar mais detalhes sobre qualquer agente — basta perguntar.",
  "Anotado! Precisa de mais alguma coisa?",
  "Perfeito. Vou monitorar e te atualizo se algo mudar.",
  "Pode contar comigo. Estou acompanhando tudo em tempo real.",
  "Feito. Quer que eu gere um relatorio sobre isso?",
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getAgentStats(): { total: number; active: number; errors: number; completed: number; waiting: number } {
  const agents = Object.values(useAgentsStore.getState().agents);
  return {
    total: agents.length,
    active: agents.filter((a) => ["researching", "thinking", "executing"].includes(a.status)).length,
    errors: agents.filter((a) => a.status === "error").length,
    completed: agents.filter((a) => a.status === "completed").length,
    waiting: agents.filter((a) => ["waiting_input", "blocked"].includes(a.status)).length,
  };
}

function fillTemplate(template: string, stats: Record<string, number>): string {
  return template.replace(/\{(\w+)\}/g, (_, key) => String(stats[key] ?? 0));
}

export function generateAmoraResponse(content: string, attachments: ChatAttachment[]): string {
  const lower = content.toLowerCase().trim();

  // Handle attachments
  if (attachments.some((a) => a.type === "audio")) {
    return pick(AUDIO_RESPONSES);
  }
  if (attachments.some((a) => a.type === "image")) {
    return pick(IMAGE_RESPONSES);
  }

  // Greetings
  if (/^(oi|ola|hey|hello|hi|e ai|bom dia|boa tarde|boa noite)\b/i.test(lower)) {
    return pick(GREETINGS);
  }

  // Status queries
  if (/status|como .*(esta|tao|anda)|relatorio|report|dashboard|agentes?/i.test(lower)) {
    const stats = getAgentStats();
    return fillTemplate(pick(STATUS_RESPONSES), stats);
  }

  // Error queries
  if (/erro|error|problema|bug|falha|fail|broken|quebr/i.test(lower)) {
    return pick(ERROR_RESPONSES);
  }

  // Task assignment
  if (/tarefa|task|faz|execute|roda|run|processa|cria|gera|envia|deploy/i.test(lower)) {
    return pick(TASK_RESPONSES);
  }

  return pick(GENERIC_RESPONSES);
}
