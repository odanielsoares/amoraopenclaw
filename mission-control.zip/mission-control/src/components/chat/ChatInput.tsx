"use client";

import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useChatStore } from "@/store/chat";
import { useAudioRecorder } from "@/hooks/useAudioRecorder";
import type { ChatAttachment } from "@/types/chat";

function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function ChatInput() {
  const [text, setText] = useState("");
  const [pendingImages, setPendingImages] = useState<ChatAttachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sendMessage = useChatStore((s) => s.sendMessage);

  const { isRecording, duration, volume, startRecording, stopRecording, cancelRecording } =
    useAudioRecorder();

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 96)}px`;
  }, [text]);

  const handleSend = useCallback(() => {
    const trimmed = text.trim();
    if (!trimmed && pendingImages.length === 0) return;
    sendMessage(trimmed, pendingImages);
    setText("");
    setPendingImages([]);
    textareaRef.current?.focus();
  }, [text, pendingImages, sendMessage]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const processFiles = useCallback((files: FileList | File[]) => {
    const images: ChatAttachment[] = [];
    for (const file of Array.from(files)) {
      if (file.type.startsWith("image/")) {
        images.push({
          id: uid(),
          type: "image",
          url: URL.createObjectURL(file),
          filename: file.name,
          mimeType: file.type,
        });
      }
    }
    if (images.length > 0) {
      setPendingImages((prev) => [...prev, ...images]);
    }
  }, []);

  // Paste handler (Cmd+V images)
  const handlePaste = useCallback(
    (e: React.ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      const files: File[] = [];
      for (const item of Array.from(items)) {
        if (item.type.startsWith("image/")) {
          const file = item.getAsFile();
          if (file) files.push(file);
        }
      }
      if (files.length > 0) {
        e.preventDefault();
        processFiles(files);
      }
    },
    [processFiles]
  );

  // Drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = () => setIsDragging(false);
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) processFiles(e.target.files);
    e.target.value = "";
  };

  const removeImage = (id: string) => {
    setPendingImages((prev) => prev.filter((img) => img.id !== id));
  };

  const handleAudioStop = async () => {
    const result = await stopRecording();
    if (result) {
      const attachment: ChatAttachment = {
        id: uid(),
        type: "audio",
        url: result.url,
        filename: "audio.webm",
        duration: result.duration,
        mimeType: "audio/webm",
      };
      sendMessage("", [attachment]);
    }
  };

  return (
    <div
      className={`border-t border-mc-border/50 bg-mc-bg/80 ${
        isDragging ? "ring-2 ring-purple-500/50 ring-inset" : ""
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Pending images preview */}
      <AnimatePresence>
        {pendingImages.length > 0 && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex gap-2 px-3 pt-2 overflow-x-auto"
          >
            {pendingImages.map((img) => (
              <div key={img.id} className="relative flex-shrink-0 group">
                <img
                  src={img.url}
                  alt={img.filename}
                  className="w-14 h-14 object-cover rounded-lg border border-mc-border"
                />
                <button
                  onClick={() => removeImage(img.id)}
                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[8px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  x
                </button>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Recording indicator */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex items-center gap-3 px-3 pt-2"
          >
            <motion.div
              className="w-3 h-3 rounded-full bg-red-500"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-xs font-mono text-red-400">
              Gravando {formatDuration(duration)}
            </span>
            <div className="flex-1 h-4 flex items-center gap-0.5">
              {Array.from({ length: 20 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="w-1 bg-red-500/60 rounded-full"
                  animate={{
                    height: `${Math.max(4, volume * 16 * (0.5 + Math.random()))}px`,
                  }}
                  transition={{ duration: 0.1 }}
                />
              ))}
            </div>
            <button
              onClick={cancelRecording}
              className="text-[10px] font-mono text-mc-muted hover:text-red-400 transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleAudioStop}
              className="text-[10px] font-mono font-bold text-purple-400 hover:text-purple-300 transition-colors"
            >
              Enviar
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Drag overlay */}
      {isDragging && (
        <div className="absolute inset-0 bg-purple-500/10 border-2 border-dashed border-purple-500/40 rounded-xl flex items-center justify-center z-10">
          <p className="text-sm font-mono text-purple-400">Solte a imagem aqui</p>
        </div>
      )}

      {/* Input bar */}
      {!isRecording && (
        <div className="flex items-end gap-2 p-2">
          {/* Attach image */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-mc-muted hover:text-purple-400 hover:bg-purple-500/10 transition-colors"
            title="Anexar imagem"
          >
            <span className="text-sm">📎</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFileSelect}
          />

          {/* Text input */}
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder="Fale com a Amora..."
            rows={1}
            className="flex-1 resize-none bg-mc-surface/60 border border-mc-border/50 rounded-xl px-3 py-2 text-xs font-mono text-mc-text placeholder:text-mc-muted/40 focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 scrollbar-thin"
            style={{ maxHeight: "96px" }}
          />

          {/* Audio record */}
          <button
            onClick={startRecording}
            className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-mc-muted hover:text-red-400 hover:bg-red-500/10 transition-colors"
            title="Gravar audio"
          >
            <span className="text-sm">🎤</span>
          </button>

          {/* Send */}
          <button
            onClick={handleSend}
            disabled={!text.trim() && pendingImages.length === 0}
            className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center bg-purple-600 hover:bg-purple-500 disabled:opacity-30 disabled:hover:bg-purple-600 transition-colors"
            title="Enviar"
          >
            <span className="text-sm">▲</span>
          </button>
        </div>
      )}
    </div>
  );
}
