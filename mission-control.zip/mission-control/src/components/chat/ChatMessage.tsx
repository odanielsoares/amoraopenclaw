"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import type { ChatMessage as ChatMessageType } from "@/types/chat";
import { AmoraAvatar } from "./AmoraAvatar";

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function renderText(text: string): React.ReactNode {
  // Simple markdown: **bold** and `code`
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={i} className="font-bold text-mc-text">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={i} className="px-1 py-0.5 rounded bg-mc-border/50 text-purple-300 text-[10px]">
          {part.slice(1, -1)}
        </code>
      );
    }
    return part;
  });
}

interface ChatMessageProps {
  message: ChatMessageType;
}

export function ChatMessageBubble({ message }: ChatMessageProps) {
  const isUser = message.role === "user";
  const [expandedImage, setExpandedImage] = useState<string | null>(null);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className={`flex items-end gap-2 ${isUser ? "flex-row-reverse" : "flex-row"}`}
      >
        {/* Avatar */}
        {!isUser && <AmoraAvatar size="sm" />}

        <div className={`max-w-[75%] flex flex-col ${isUser ? "items-end" : "items-start"}`}>
          {/* Attachments */}
          {message.attachments.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-1">
              {message.attachments.map((att) => {
                if (att.type === "image") {
                  return (
                    <button
                      key={att.id}
                      onClick={() => setExpandedImage(att.url)}
                      className="rounded-lg overflow-hidden border border-mc-border/50 hover:border-purple-500/50 transition-colors"
                    >
                      <img
                        src={att.url}
                        alt={att.filename}
                        className="max-w-[200px] max-h-[150px] object-cover"
                      />
                    </button>
                  );
                }
                if (att.type === "audio") {
                  return (
                    <div
                      key={att.id}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg border border-mc-border/50 ${
                        isUser ? "bg-blue-900/30" : "bg-purple-900/30"
                      }`}
                    >
                      <span className="text-xs">🎤</span>
                      <audio controls src={att.url} className="h-8 max-w-[200px]" />
                      {att.duration && (
                        <span className="text-[9px] font-mono text-mc-muted">
                          {att.duration}s
                        </span>
                      )}
                    </div>
                  );
                }
                return null;
              })}
            </div>
          )}

          {/* Text bubble */}
          {message.content && (
            <div
              className={`px-3 py-2 rounded-xl text-xs font-mono leading-relaxed ${
                isUser
                  ? "bg-blue-900/60 text-blue-100 rounded-br-sm"
                  : "bg-purple-900/40 text-purple-100 rounded-bl-sm border border-purple-500/20"
              }`}
            >
              {renderText(message.content)}
            </div>
          )}

          {/* Timestamp */}
          <span className="text-[9px] font-mono text-mc-muted/50 mt-0.5 px-1">
            {formatTime(message.timestamp)}
            {isUser && message.status === "sending" && " · enviando..."}
            {isUser && message.status === "error" && " · erro"}
          </span>
        </div>
      </motion.div>

      {/* Image lightbox */}
      {expandedImage && (
        <motion.div
          className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center cursor-pointer"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => setExpandedImage(null)}
        >
          <img
            src={expandedImage}
            alt="Expanded"
            className="max-w-[90vw] max-h-[90vh] object-contain rounded-lg"
          />
        </motion.div>
      )}
    </>
  );
}
