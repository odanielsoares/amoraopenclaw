"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useChatStore } from "@/store/chat";
import { AmoraAvatar } from "./AmoraAvatar";
import { ChatMessageBubble } from "./ChatMessage";
import { ChatInput } from "./ChatInput";

function TypingIndicator() {
  return (
    <div className="flex items-end gap-2">
      <AmoraAvatar size="sm" typing />
      <div className="px-3 py-2 rounded-xl rounded-bl-sm bg-purple-900/40 border border-purple-500/20">
        <div className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-purple-400"
              animate={{ opacity: [0.3, 1, 0.3], y: [0, -3, 0] }}
              transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function TokenGate({ onAuthenticated }: { onAuthenticated: () => void }) {
  const [token, setToken] = useState("");
  const [error, setError] = useState(false);
  const [checking, setChecking] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) return;

    setChecking(true);
    setError(false);

    // Validate token via API route (server-side comparison)
    try {
      const res = await fetch("/api/auth/amora", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: token.trim() }),
      });

      if (res.ok) {
        sessionStorage.setItem("amora_auth", token.trim());
        onAuthenticated();
      } else {
        setError(true);
      }
    } catch {
      // Fallback: if API doesn't exist yet, accept any non-empty token in dev
      if (process.env.NODE_ENV === "development") {
        sessionStorage.setItem("amora_auth", token.trim());
        onAuthenticated();
      } else {
        setError(true);
      }
    }

    setChecking(false);
  };

  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="w-full max-w-[280px] space-y-3">
        <div className="flex flex-col items-center gap-2 mb-4">
          <AmoraAvatar size="lg" />
          <p className="text-xs font-mono text-mc-muted text-center">
            Insira o token de acesso para falar com a Amora
          </p>
        </div>
        <input
          type="password"
          value={token}
          onChange={(e) => {
            setToken(e.target.value);
            setError(false);
          }}
          placeholder="Token de acesso"
          autoFocus
          className={`w-full bg-mc-surface/60 border rounded-lg px-3 py-2 text-xs font-mono text-mc-text placeholder:text-mc-muted/40 focus:outline-none focus:ring-1 transition-colors ${
            error
              ? "border-red-500/50 focus:border-red-500 focus:ring-red-500/20"
              : "border-mc-border/50 focus:border-purple-500/50 focus:ring-purple-500/20"
          }`}
        />
        {error && (
          <p className="text-[10px] font-mono text-red-400">Token invalido. Tente novamente.</p>
        )}
        <button
          type="submit"
          disabled={!token.trim() || checking}
          className="w-full py-2 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-xs font-mono font-bold text-white transition-colors"
        >
          {checking ? "Verificando..." : "Acessar"}
        </button>
      </form>
    </div>
  );
}

export function AmoraChat() {
  const { messages, isOpen, isAmoraTyping, unreadCount } = useChatStore();
  const toggleChat = useChatStore((s) => s.toggleChat);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [authenticated, setAuthenticated] = useState(false);

  // Check sessionStorage on mount
  useEffect(() => {
    const stored = sessionStorage.getItem("amora_auth");
    if (stored) setAuthenticated(true);
  }, []);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current && isOpen) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length, isAmoraTyping, isOpen]);

  const handleLogout = useCallback(() => {
    sessionStorage.removeItem("amora_auth");
    setAuthenticated(false);
  }, []);

  return (
    <>
      {/* Floating button (when closed) */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleChat}
            className="fixed bottom-4 left-4 z-30 w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center shadow-lg"
            style={{ boxShadow: "0 0 20px rgba(168, 85, 247, 0.4)" }}
          >
            <span className="text-xl">🍇</span>

            {/* Unread badge */}
            {unreadCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center"
              >
                <span className="text-[9px] font-mono font-bold text-white">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              </motion.div>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat dock */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ y: 500, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 500, opacity: 0 }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-[320px] z-30 flex flex-col bg-[#0d1117] border-t border-l border-r border-purple-500/20 rounded-t-xl overflow-hidden"
            style={{
              height: "400px",
              boxShadow: "0 -4px 30px rgba(168, 85, 247, 0.1)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-2 border-b border-mc-border/50 bg-purple-900/10 flex-shrink-0">
              <div className="flex items-center gap-2">
                <AmoraAvatar size="sm" typing={isAmoraTyping} />
                <div>
                  <h3 className="text-xs font-mono font-bold text-purple-300">Amora</h3>
                  <p className="text-[9px] font-mono text-mc-muted">
                    {isAmoraTyping ? "digitando..." : "COO · Online"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {authenticated && (
                  <button
                    onClick={handleLogout}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-mc-muted hover:text-red-400 hover:bg-red-500/10 transition-colors"
                    title="Desconectar"
                  >
                    <span className="text-xs">🔒</span>
                  </button>
                )}
                <button
                  onClick={toggleChat}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-mc-muted hover:text-mc-text hover:bg-mc-border/30 transition-colors"
                  title="Minimizar"
                >
                  <span className="text-sm leading-none">▾</span>
                </button>
              </div>
            </div>

            {!authenticated ? (
              <TokenGate onAuthenticated={() => setAuthenticated(true)} />
            ) : (
              <>
                {/* Messages */}
                <div
                  ref={scrollRef}
                  className="flex-1 overflow-y-auto px-4 py-3 space-y-3 scrollbar-thin"
                >
                  {messages.map((msg) => (
                    <ChatMessageBubble key={msg.id} message={msg} />
                  ))}
                  {isAmoraTyping && <TypingIndicator />}
                </div>

                {/* Input */}
                <ChatInput />
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
