"use client";

import { motion } from "framer-motion";

interface AmoraAvatarProps {
  size?: "sm" | "md" | "lg";
  typing?: boolean;
}

const sizes = {
  sm: "w-7 h-7 text-sm",
  md: "w-9 h-9 text-base",
  lg: "w-12 h-12 text-xl",
};

export function AmoraAvatar({ size = "md", typing = false }: AmoraAvatarProps) {
  return (
    <div className="relative flex-shrink-0">
      <div
        className={`${sizes[size]} rounded-full flex items-center justify-center border-2 border-purple-500 bg-purple-500/20`}
        style={{ boxShadow: "0 0 12px rgba(168, 85, 247, 0.3)" }}
      >
        <span>🍇</span>
      </div>
      {typing && (
        <motion.div
          className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-purple-500 flex items-center justify-center"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
        >
          <span className="text-[6px] text-white font-bold">...</span>
        </motion.div>
      )}
    </div>
  );
}
